<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ezmultistore}prestashop>ezmultistore_afff3a690ba696835bab19a94cc536cc'] = ' EZ MultiStore : Gestionnaire de magasin';
$_MODULE['<{ezmultistore}prestashop>ezmultistore_d31a5b29fe4abcc6cf6a912891895d20'] = 'Ce module vous permet d\'avoir différentes factures pour chacun de vos magasins.';
$_MODULE['<{ezmultistore}prestashop>ezmultistore_44d7b2036166452a10240ddf1d7e93b0'] = 'Voulez-vous vraiment désintaller ?';
$_MODULE['<{ezmultistore}prestashop>ezmultistore_d718e72cb7f2450dc77d0e296cbe7e22'] = 'Retraits commandes';
$_MODULE['<{ezmultistore}prestashop>ezmultistore_046f3e7658ca8272875aadce57b68c50'] = 'Retrait en magasin';
$_MODULE['<{ezmultistore}prestashop>ezmultistore_f97929e473fa62317387f155f6156060'] = 'Commande prête en 2 heures.';
$_MODULE['<{ezmultistore}prestashop>ezmultistore_4d9c422572340aa35e8bac9f7e5ea9b5'] = 'Retrait : ';
$_MODULE['<{ezmultistore}prestashop>ezmultistore_f92bda2afcbe3511e9e748c86a457df3'] = 'Choisissez votre magasin';
